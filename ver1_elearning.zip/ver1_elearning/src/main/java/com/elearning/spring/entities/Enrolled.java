package com.elearning.spring.entities;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "enrolled")
public class Enrolled {
	
	@EmbeddedId
	private EnrolledCompositeKey enroll_cpkey;

	public EnrolledCompositeKey getEnroll_cpkey() {
		return enroll_cpkey;
	}

	public void setEnroll_cpkey(EnrolledCompositeKey enroll_cpkey) {
		this.enroll_cpkey = enroll_cpkey;
	}
	
	
	

}
