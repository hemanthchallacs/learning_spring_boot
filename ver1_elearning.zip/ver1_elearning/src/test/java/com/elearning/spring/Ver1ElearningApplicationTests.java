package com.elearning.spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ver1ElearningApplicationTests {

	@Test
	void contextLoads() {
	}

}
